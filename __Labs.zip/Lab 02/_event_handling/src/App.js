import React  from 'react';

import './App.css';

import MyButton from './_MyButton';
import MyInput from './_MyInput';
import MyList from './_MyList';
import MyListComponent from './_MyList_Component';
import MyButtonInline from './_MyButton_Inline';

// The items to pass to "<MyListComponent >" as a property.
const items = [
  { id: 0, name: 'First' },
  { id: 1, name: 'Second' },
  { id: 2, name: 'Third' }
  ];
  
function App() {
  
  return (
    <div className="App">
      <MyButton>Click Me</MyButton>
      <MyInput />
      <MyList />
      <MyListComponent items = {items}/>
      <MyButtonInline >Click Me Inline</MyButtonInline>
    </div>
  );
}

export default App;
