import React from 'react';
import { render } from 'react-dom';

import MyList from './MyList';

render(<MyList />, document.getElementById('root'));
