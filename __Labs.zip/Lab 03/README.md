# The Road to Learn React - Hacker News Client

[![Build Status](https://travis-ci.org/the-road-to-learn-react/hackernews-client.svg?branch=master)](https://travis-ci.org/the-road-to-learn-react/hackernews-client) [![Slack](https://slack-the-road-to-learn-react.wieruch.com/badge.svg)](https://slack-the-road-to-learn-react.wieruch.com/) [![Greenkeeper badge](https://badges.greenkeeper.io/the-road-to-learn-react/hackernews-client.svg)](https://greenkeeper.io/)

The application you will build when you read the book to [learn React](https://www.robinwieruch.de/the-road-to-learn-react/).

Find all chapter outcomes over [here](https://github.com/the-road-to-learn-react/hackernews-client).

After reading the book, you can continue to [learn more about JavaScript](https://roadtoreact.com).
